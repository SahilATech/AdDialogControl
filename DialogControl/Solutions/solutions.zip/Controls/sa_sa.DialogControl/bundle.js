/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./DialogControl/HelloWorld.tsx":
/*!**************************************!*\
  !*** ./DialogControl/HelloWorld.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   HelloWorld: () => (/* binding */ HelloWorld)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);\n/* eslint-disable @typescript-eslint/no-explicit-any */\n\n\nclass HelloWorld extends react__WEBPACK_IMPORTED_MODULE_0__.Component {\n  constructor(props) {\n    super(props);\n    this.toggleDialog = () => {\n      this.setState(prevState => ({\n        isDialogHidden: !prevState.isDialogHidden\n      }));\n    };\n    this.handleDismissEvent = () => {\n      this.setState(prevState => ({\n        isDialogHidden: !prevState.isDialogHidden\n      }));\n    };\n    this.handleCancelEvent = () => {\n      this.setState(prevState => ({\n        isDialogHidden: !prevState.isDialogHidden\n      }));\n    };\n    this.handleSaveEvent = () => {\n      this.setState(prevState => ({\n        isDialogHidden: !prevState.isDialogHidden\n      }));\n      this.props.onChange(this.state.optionSelected);\n    };\n    this.handleSaveButton = () => {\n      window[\"pcfDialogControl_\".concat(this.props.uniqueKey)].saveFunctionOverride();\n    };\n    this.handleDismissButton = () => {\n      window[\"pcfDialogControl_\".concat(this.props.uniqueKey)].DismissFunctionOverride();\n    };\n    this.handleCancelButton = () => {\n      window[\"pcfDialogControl_\".concat(this.props.uniqueKey)].cancelFunctionOverride();\n    };\n    this.onChangeRenderDescription = (ev, option) => {\n      if (option) {\n        window[\"pcfDialogControl_\".concat(this.props.uniqueKey)].currentSelectedOption = option.key;\n        this.setState({\n          optionSelected: option.key\n        });\n      }\n    };\n    this.state = {\n      modelProps: {\n        isBlocking: !props.hideOnOutsideClick,\n        topOffsetFixed: props.topOffsetFixed,\n        styles: {\n          main: {\n            minWidth: \"\".concat(props.minWidth, \" !important\"),\n            maxWidth: \"\".concat(props.maxWidth, \" !important\")\n          }\n        },\n        dragOptions: props.isDailogDraggable ? {\n          moveMenuItemText: \"Move\",\n          closeMenuItemText: \"Close\",\n          menu: _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.ContextualMenu,\n          keepInBounds: props.isDailogKeepInBounds\n        } : undefined\n      },\n      dialogContentProps: {\n        type: props.dialogType,\n        title: props.titleText,\n        subText: props.descriptionText\n      },\n      isDialogHidden: true,\n      optionSelected: props.presentKeyinField\n    };\n    // Attach methods and state to the global window object\n    window[\"pcfDialogControl_\".concat(props.uniqueKey)] = {\n      state: this.state,\n      toggleDialog: this.toggleDialog,\n      presentKeyinDatabase: props.presentKeyinField,\n      currentSelectedOption: props.presentKeyinField,\n      DismissFunctionOverride: this.handleDismissEvent,\n      saveFunctionOverride: this.handleSaveEvent,\n      cancelFunctionOverride: this.handleCancelEvent\n    };\n  }\n  renderShowButton() {\n    if (this.props.ShowDialogButtonVisible) {\n      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DefaultButton, {\n        secondaryText: this.props.openDialogButtonLabel,\n        onClick: this.toggleDialog,\n        text: this.props.openDialogButtonLabel\n      });\n    }\n    return null;\n  }\n  render() {\n    var _a;\n    var {\n      isDialogHidden,\n      dialogContentProps,\n      modelProps,\n      optionSelected\n    } = this.state;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, this.renderShowButton()), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Dialog, {\n      hidden: isDialogHidden,\n      onDismiss: this.handleDismissButton,\n      dialogContentProps: dialogContentProps,\n      modalProps: modelProps\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.ChoiceGroup, {\n      defaultSelectedKey: this.props.presentKeyinField,\n      options: this.props.options,\n      onChange: this.onChangeRenderDescription\n    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"h1\", null, \"Description\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", null, ((_a = this.props.options.find(option => option.key === optionSelected)) === null || _a === void 0 ? void 0 : _a.description) || 'No description available')), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DialogFooter, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PrimaryButton, {\n      onClick: this.handleSaveButton,\n      text: this.props.saveButtonLabel\n    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DefaultButton, {\n      onClick: this.handleCancelButton,\n      text: this.props.cancelButtonLabel\n    }))));\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DialogControl/HelloWorld.tsx?");

/***/ }),

/***/ "./DialogControl/index.ts":
/*!********************************!*\
  !*** ./DialogControl/index.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DialogControl: () => (/* binding */ DialogControl)\n/* harmony export */ });\n/* harmony import */ var _HelloWorld__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HelloWorld */ \"./DialogControl/HelloWorld.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass DialogControl {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {\n    this.onChange = newValue => {\n      this._latestValue = newValue;\n      this.notifyOutputChanged();\n    };\n  }\n  /**\r\n   * Initializes the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here; use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a control's lifecycle by calling 'setControlState' in the Mode interface.\r\n   */\n  init(context, notifyOutputChanged, state) {\n    var _a;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this._context = context;\n    this._presentKeyinField = (_a = context.parameters.InputOutputValue.raw) !== null && _a !== void 0 ? _a : \"\";\n    this._titleText = context.parameters.titleText.raw;\n    this._descriptionText = context.parameters.descriptionText.raw;\n    this._options = context.parameters.options.raw;\n    this._dialogType = Number(context.parameters.dialogType.raw);\n    this._hideOnOutsideClick = context.parameters.hideOnOutsideClick.raw;\n    this._saveButtonLabel = context.parameters.saveBtnLabel.raw;\n    this._cancelButtonLabel = context.parameters.cancelBtnLabel.raw;\n    this._isDialogKeepInBounds = context.parameters.isDailogKeepInBounds.raw;\n    this._isDialogDraggable = context.parameters.isDailogDraggable.raw;\n    this._minWidth = context.parameters.minWidth.raw;\n    this._maxWidth = context.parameters.maxWidth.raw;\n    this._isTopOffsetFixed = context.parameters.isTopOffsetFixed.raw;\n    this._openDialogButtonLabel = context.parameters.openDialogButtonLabel.raw;\n    this._isShowDialogButtonVisible = context.parameters.isShowDialogButtonVisible.raw;\n    try {\n      this._parseJson = JSON.parse(this._options);\n    } catch (error) {\n      throw new Error(\"The provided options array is invalid. Please ensure it follows the correct format. Here is an example of a valid options array (All parameters are optional except key):\\n\" + '[\\n' + '  { \"key\": \"A\", \"iconProps\": { \"iconName\": \"CalendarDay\" }, \"text\": \"Option A\", \"disabled\": false, \"description\": \"Lorem ipsum dolor sit amet\" },\\n' + '  { \"key\": \"B\", \"iconProps\": { \"iconName\": \"Calendar\" }, \"text\": \"Option B\", \"disabled\": true, \"description\": \"Consectetur adipiscing elit\" },\\n' + '  { \"key\": \"C\", \"iconProps\": { \"iconName\": \"Add\" }, \"text\": \"Option C\", \"disabled\": false, \"description\": \"Sed do eiusmod tempor incididunt\" }\\n' + ']');\n    }\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values set up by the customizer mapped to names defined in the manifest, as well as utility functions.\r\n   * @returns ReactElement root React element for the control.\r\n   */\n  updateView(context) {\n    var _a, _b;\n    var props = {\n      presentKeyinField: this._presentKeyinField,\n      titleText: this._titleText,\n      descriptionText: this._descriptionText,\n      options: this._parseJson,\n      dialogType: this._dialogType,\n      hideOnOutsideClick: this._hideOnOutsideClick,\n      saveButtonLabel: this._saveButtonLabel,\n      cancelButtonLabel: this._cancelButtonLabel,\n      isDailogDraggable: this._isDialogDraggable,\n      isDailogKeepInBounds: this._isDialogKeepInBounds,\n      minWidth: this._minWidth,\n      maxWidth: this._maxWidth,\n      topOffsetFixed: this._isTopOffsetFixed,\n      openDialogButtonLabel: this._openDialogButtonLabel,\n      onChange: this.onChange,\n      uniqueKey: (_b = (_a = this._context.parameters.InputOutputValue.attributes) === null || _a === void 0 ? void 0 : _a.LogicalName) !== null && _b !== void 0 ? _b : \"\",\n      ShowDialogButtonVisible: this._isShowDialogButtonVisible\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_HelloWorld__WEBPACK_IMPORTED_MODULE_0__.HelloWorld, props);\n  }\n  /**\r\n   * Called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in the manifest, expecting object[s] for property marked as \"bound\" or \"output\".\r\n   */\n  getOutputs() {\n    return {\n      InputOutputValue: this._latestValue\n    };\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup, i.e., cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to clean up control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DialogControl/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./DialogControl/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('sa.DialogControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DialogControl);
} else {
	var sa = sa || {};
	sa.DialogControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DialogControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}